def foo():
    print("Hi")